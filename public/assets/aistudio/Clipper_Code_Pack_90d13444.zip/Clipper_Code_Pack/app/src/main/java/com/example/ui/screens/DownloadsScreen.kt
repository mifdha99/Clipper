package com.example.ui.screens

import android.content.Intent
import.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.ui.viewmodel.DownloadViewModel
import java.io.File

@Composable
fun DownloadsScreen(viewModel: DownloadViewModel, modifier: Modifier = Modifier) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Download video", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(
            value = state.url, onValueChange = viewModel::setUrl,
            label = { Text("Direct URL MP4") }, modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = viewModel::startDownload, enabled = !state.busy) { Text("DOWNLOAD") }
            if (state.busy) OutlinedButton(onClick = viewModel::cancelDownload) { Text("BATAL") }
            OutlinedButton(onClick = viewModel::refresh) { Text("Refresh") }
        }
        if (state.busy) {
            LinearProgressIndicator(
                progress = { (state.percent ?: 0) / 100f },
                modifier = Modifier.fillMaxWidth()
            )
            Text("${state.percent?.let { "$it%" } ?: "Progress"} • ${state.receivedBytes / 1024} KB")
        }
        state.message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        HorizontalDivider()
        Text("Downloads (${state.files.size})", style = MaterialTheme.typography.titleMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(state.files, key = { it.absolutePath }) { file ->
                DownloadRow(file, onPlay = { openVideo(context, file) }, onDelete = { viewModel.delete(file) })
            }
        }
    }
}

@Composable
private fun DownloadRow(file: File, onPlay: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(file.name, maxLines = 2)
                Text("${file.length() / (1024 * 1024)} MB", style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onPlay) { Text("PLAY") }
            TextButton(onClick = onDelete) { Text("HAPUS") }
        }
    }
}

private fun openVideo(context: android.content.Context, file: File) {
    // Use FileProvider in production; fallback content URI requires provider configuration.
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    context.startActivity(intent)
}
