INTEGRASI KE REPO `mifdha99/Clipper`
=====================================

A. Dependency
------------
Tambahkan ke app/build.gradle.kts di blok dependencies:
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.core:core-ktx:1.15.0")

B. FileProvider (untuk tombol PLAY di DownloadsScreen)
----------------------------------------------------
Di AndroidManifest.xml, di dalam <application>:
    <provider
        android:name="androidx.core.content.FileProvider"
        android:authorities="${applicationId}.fileprovider"
        android:exported="false"
        android:grantUriPermissions="true">
        <meta-data
            android:name="android.support.FILE_PROVIDER_PATHS"
            android:resource="@xml/file_paths" />
    </provider>

Buat app/src/main/res/xml/file_paths.xml:
    <?xml version="1.0" encoding="utf-8"?>
    <paths xmlns:android="http://schemas.android.com/apk/res/android">
        <external-files-path name="app_files" path="." />
    </paths>

C. ViewModel
------------
Di Activity/nav graph, buat DownloadViewModel dengan viewModel() atau factory
AndroidViewModel yang sesuai. Tambahkan route Downloads dan panggil:
    DownloadsScreen(viewModel = downloadViewModel)

D. Download storage
------------------
Pack menyimpan di:
    getExternalFilesDir(null)/Downloads
File private app storage (tidak otomatis muncul Galeri). Export final clip
menggunakan VideoExportEngine existing yang menulis ke Movies/Clipper.

E. AI viral moment
------------------
ViralMomentModels hanya model + ranking. Untuk AI nyata:
- extract audio dan transcribe dengan timestamp (model/API speech-to-text),
- kirim transcript bertimestamp ke Gemini,
- parse JSON kandidat (startMs/endMs/title/hook/reason/score),
- validasi timestamp terhadap durasi video,
- jangan membuat timestamp random atau fallback yang seolah AI berhasil.
Kunci API jangan hardcode atau commit ke repo.

F. Build
--------
    ./gradlew assembleDebug

Catatan: package app existing adalah com.aistudio.tubeclip.xqvzr dan namespace
com.example. FileProvider authority menggunakan applicationId otomatis.
