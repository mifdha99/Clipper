CLIPPER CODE PACK (Android Kotlin / Jetpack Compose)
===================================================

Package target: com.example (matches the existing Clipper repository namespace).

Contents:
- DownloadRepository.kt: actual direct-video downloader (HTTP(S), progress, cancellation,
  Content-Type validation, temp file + atomic rename).
- DownloadViewModel.kt: Compose-friendly download state + list of downloaded files.
- DownloadsScreen.kt: simple Downloads list and playback action.
- ViralMomentModels.kt: candidate data models + ranking helper (heuristic only; not an AI model).
- ClipExportHelper.kt: adapter calling the existing VideoExportEngine.trimAndExportVideo.
- INTEGRATION.md: wiring instructions and limitations.

IMPORTANT HONEST LIMITATIONS
---------------------------
1) This pack downloads direct video URLs whose server actually returns video bytes.
   It does NOT extract MP4 from ordinary You.com/YouTube watch URLs. YouTube's
   official APIs do not provide a general MP4 download endpoint.
2) Automatic "viral moment" detection needs a real transcript/audio pipeline and Gemini
   API configuration. This pack provides the data/ranking contract only; it does not
   pretend to analyze a video or produce fabricated timestamps.
3) Export adapter uses the existing VideoExportEngine in your Clipper project. The
   existing engine is a basic MediaExtractor/MediaMuxer trim/remux, not crop/captions/
   effects or frame-accurate transcoding.
4) This is an integration code pack, not a replacement APK and not a full copy of your
   repository. Merge the files into the existing project and run Gradle build.
